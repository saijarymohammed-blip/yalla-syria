// =====================================================
// إعداد الخادم (Supabase). اتركهما فارغين لتشغيل التطبيق محلياً.
// بعد إنشاء مشروع Supabase: Project Settings → API
// انسخ Project URL و anon public key والصقهما هنا.
// (مفتاح anon آمن للنشر العلني؛ الحماية تتم عبر قواعد RLS في schema.sql)
// =====================================================
window.YALLA_CONFIG = {
  SUPABASE_URL: '',
  SUPABASE_ANON_KEY: ''
};
